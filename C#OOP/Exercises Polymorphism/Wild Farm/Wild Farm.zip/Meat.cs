﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm
{
    public class Meat : Food
    {       

        public Meat(double quantity) : base(quantity)
        {
            
        }
    }
}
