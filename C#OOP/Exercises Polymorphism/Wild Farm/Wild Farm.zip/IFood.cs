﻿namespace Wild_Farm
{
    public interface IFood
    {
        double Quantity { get; }
    }
}