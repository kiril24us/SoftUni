﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm
{
    public class Seeds : Food
    {
        public Seeds(double quantity) : base(quantity)
        {
            
        }
    }
}
